package com.mindtree.cricketmanagementsnippet.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.cricketmanagementsnippet.models.VenueModel;

@Repository
public interface VenueModelRepo extends JpaRepository<VenueModel,Integer>{

	Object findByVenueName(String venueName);


}
