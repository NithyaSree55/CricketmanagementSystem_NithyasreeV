package com.mindtree.cricketmanagementsnippet.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.cricketmanagementsnippet.models.EventModel;
import com.mindtree.cricketmanagementsnippet.models.RefereeModel;

@Repository
public interface RefereeModelRepo extends JpaRepository<RefereeModel,Integer> {

	Object findByRefereeName(String refereeName);


}
