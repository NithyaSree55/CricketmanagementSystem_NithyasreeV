package com.mindtree.cricketmanagementsnippet.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.cricketmanagementsnippet.models.TeamModel;

@Repository
public interface TeamRepo extends JpaRepository<TeamModel,Integer>{


}
