package com.mindtree.cricketmanagementsnippet.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.cricketmanagementsnippet.models.User;
import com.mindtree.cricketmanagementsnippet.repositories.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;
	
	public User createUser(User user) throws Exception {
		User foundRegister=userRepository.findByEmailAndUsername(user.getEmail(), user.getUsername());
		if(foundRegister==null)
		return userRepository.save(user);
		else
			return null;
	}
	
	public List<User> getAllUsers(){
		return userRepository.findAll();
	}
	
	public void deleteUser(int id)throws Exception {
		userRepository.deleteById(id);
	}

	public User updateUser(User user)throws Exception {
		return userRepository.save(user);
	}
}
