package com.mindtree.cricketmanagementsnippet.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.cricketmanagementsnippet.models.EventModel;
import com.mindtree.cricketmanagementsnippet.models.User;
import com.mindtree.cricketmanagementsnippet.repositories.EventModelRepo;
import com.mindtree.cricketmanagementsnippet.repositories.RefereeModelRepo;
import com.mindtree.cricketmanagementsnippet.repositories.VenueModelRepo;
 

@Service
public class EventModelService {
    @Autowired
    private EventModelRepo eventmodelrepo;
    
    @Autowired
    private RefereeModelRepo refereeModelRepo;
    
    @Autowired
    private VenueModelRepo venueModelRepo;
    
    
 
    public EventModelService() {
		super();
		// TODO Auto-generated constructor stub
	}


	public EventModelService(EventModelRepo eventmodelrepo, RefereeModelRepo refereeModelRepo,
			VenueModelRepo venueModelRepo) {
		super();
		this.eventmodelrepo = eventmodelrepo;
		this.refereeModelRepo = refereeModelRepo;
		this.venueModelRepo = venueModelRepo;
	}


	public EventModel bookEvent(EventModel eventmodel) {
    	if(venueModelRepo.findByVenueName(eventmodel.getVenueName())!=null) {
    		if(refereeModelRepo.findByRefereeName(eventmodel.getRefereeName())!=null) {
    			return eventmodelrepo.save(eventmodel);
    		}
    		else {
    			return null;
    		}
    	}
		else
			return null;
	}
    
 
    public List<EventModel> viewAllEventModel() {
        return eventmodelrepo.findAll();
    }
 
//    public EventModel editevent(EventModel eventmodel,int eventId ) {
//        // TODO Auto-generated method stub
//        return eventmodelrepo.save(eventmodel);
//    }
 
    public void deleteEvent(int id) {
        eventmodelrepo.deleteById(id);

    }


	public EventModel editevent(EventModel eventmodel) {
		
		return eventmodelrepo.save(eventmodel);
	}


	
 

   

}
