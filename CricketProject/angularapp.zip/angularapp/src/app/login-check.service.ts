import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginCheckService {

  constructor(
    private http: HttpClient
  ) { }

  login(email: any, password: any): Observable<any>{
    const url=`http://localhost:8093/auth`;
    return this.http.post(url, email, password);
  }
}
